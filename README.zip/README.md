# Semana de Imersao Dev 7 da Alura - Cursos Online.

#POWERED BY:
<div style="display:inline-block">
 <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg" alt="Logo javascript" style="width:60px; height:60px;"/>
 <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg" style="width:60px; height:60px;"/>
 <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg" alt="Logo CSS 3" style="width:60px; height:60px;"/>
</div>
<br>
<div>
<strong>Aula 1 - Criação de um conversor de Moedas.</strong><br>
<strong>Aula 2 - Criação do Jogo Mentalize.</strong><br>
<strong>Aula 3 - Criação do Alura Flix - Uma pagian de filmes.</strong>
</div>


